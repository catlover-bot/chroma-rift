const fs=require('node:fs'),path=require('node:path'),vm=require('node:vm');
const req=require('node:module').createRequire(path.join(process.cwd(),'package.json'));
const parser=req('@babel/parser'),{TraceMap,decodedMappings}=req('@jridgewell/trace-mapping');
const index=JSON.parse(fs.readFileSync('/home/mhirotaka/workspace/chroma-rift-goal012/.expo/goal014-1/exports/final/evidence/goal014-1-export-index.json','utf8')),output={};
for(const profile of ['preview','production']){
 const item=index[profile],code=fs.readFileSync(path.join(item.directory,item.bundle),'utf8');
 const map=new TraceMap(JSON.parse(fs.readFileSync(path.join(item.directory,item.bundle+'.map'),'utf8'))),mappings=decodedMappings(map),records=new Map();
 for(const statement of parser.parse(code,{sourceType:'script'}).program.body){
  const call=statement.type==='ExpressionStatement'&&statement.expression;
  if(call?.type!=='CallExpression'||call.callee.name!=='__d')continue;
  const [factory,id,deps]=call.arguments;let source;
  for(let line=factory.loc.start.line-1;!source&&line<factory.loc.end.line;line++){
   const segment=(mappings[line]??[]).find(s=>s.length>=4&&(line!==factory.loc.start.line-1||s[0]>=factory.loc.start.column)&&(line!==factory.loc.end.line-1||s[0]<factory.loc.end.column));
   if(segment)source=map.resolvedSources[segment[1]];
  }
  records.set(id.value,{source,factory:code.slice(factory.start,factory.end),deps:deps.elements.map(x=>x.value)});
 }
 const identity=[...records].find(([,r])=>r.source?.endsWith('/src/platform/buildIdentity.ts')||r.source==='src/platform/buildIdentity.ts');
 if(!identity)throw Error('Missing mapped buildIdentity factory');
 const cache=new Map(),substitutions=[],evaluated=[];const context=vm.createContext({console});
 function load(id){
  if(cache.has(id))return cache.get(id).exports;
  const r=records.get(id);if(!r)throw Error('Missing dependency '+id);
  if(/\/expo-constants\//.test(r.source)){substitutions.push({source:r.source,value:'empty native Constants metadata'});return {__esModule:true,default:{}};}
  if(!r.source&&r.deps.length===0){const m={exports:{}};vm.runInContext('('+r.factory+')',context)(context,()=>{throw Error('Unexpected app.json import');},null,null,m,m.exports,[]);if(JSON.stringify(m.exports)!==JSON.stringify(JSON.parse(fs.readFileSync(path.join(process.cwd(),'app.json'),'utf8'))))throw Error('Unmapped factory differs from app.json');cache.set(id,m);evaluated.push('unmapped app.json factory (value matches local app.json)');return m.exports;}
  if(!/src\/platform\/buildIdentity\.ts$|(?:^|\/)app\.json$|@babel\/runtime\/helpers\//.test(r.source))throw Error('Unexpected dependency '+id+' '+r.source+' '+r.factory.slice(0,100));
  const m={exports:{}};cache.set(id,m);evaluated.push(r.source);
  const getDefault=id=>{const x=load(id);return x.__esModule?x.default:x;};const getAll=id=>{const x=load(id);return x.__esModule?x:{...x,default:x};};
  vm.runInContext('('+r.factory+')',context)(context,load,getDefault,getAll,m,m.exports,r.deps);return m.exports;
 }
 const exports=load(identity[0]),actual=exports.buildIdentity(),enabled=exports.internalDiagnosticsEnabled();
 if(actual.code!=='goal-014-1-audio-ja-r1'||actual.profileMarker!==profile||actual.bundleSource!=='release-js'||actual.nativeBuild!=='unknown'||enabled!==(profile==='preview'))throw Error('Incorrect compiled profile '+JSON.stringify({actual,enabled}));
 output[profile]={bundleSha256:item.sha256,actualIdentity:actual,internalDiagnosticsEnabled:enabled,evaluatedFactories:evaluated,substitutions,method:'Evaluate actual mapped minified buildIdentity and its Babel/app.json dependency factories; substitute unavailable native Constants metadata only. No native/iPhone identity measurement.'};
}
fs.writeFileSync('/home/mhirotaka/workspace/chroma-rift-goal012/.expo/goal014-1/exports/final/evidence/goal014-1-profile-proof.json',JSON.stringify(output,null,2)+'\n');console.log(JSON.stringify(output,null,2));
