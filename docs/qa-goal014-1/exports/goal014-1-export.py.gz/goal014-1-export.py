from pathlib import Path
import subprocess, os, json, hashlib, datetime, gzip, re

root = Path('/home/mhirotaka/workspace/chroma-rift-goal012')
prefix = 'goal014-1-'
evidence = root / '.expo/goal014-1/exports/final/evidence'
evidence.mkdir(parents=True, exist_ok=True)
index_path = Path(str(evidence) + '/' + prefix + 'export-index.json')
profile_script = Path(str(evidence) + '/' + prefix + 'profile-proof.cjs')
profile_output = Path(str(evidence) + '/' + prefix + 'profile-proof.json')
report_path = root / 'docs/qa-goal014-1/exports/bundles.json'
required = ['src/audio/nativeSession.ts', 'src/audio/diagnostics.ts', 'src/audio/nativeBackend.ts', 'src/platform/supportDiagnostics.ts', 'src/platform/diagnosticText.ts', 'src/screens/SupportInformation.tsx', 'src/screens/FirstPersonScreen.tsx', 'src/app/playerText.ts', 'src/rendering/firstPerson/controlLayout.ts', 'src/audio/owner.ts', 'src/audio/musicDirector.ts', 'src/screens/ChapterMusic.tsx', 'src/rendering/firstPerson/chapterAudio.ts', 'src/rendering/firstPerson/runtimeController.ts', 'src/domain/stages/mirror-corridor-v1/binding.ts', 'src/domain/stages/departure-control-v1/binding.ts', 'src/rendering/firstPerson/nativeDefaultFramebuffer.ts',
            'src/rendering/firstPerson/nativeGlObserver.ts',
            'src/rendering/firstPerson/nativeGlSession.ts',
            'src/platform/buildIdentity.ts']
sha = lambda data: hashlib.sha256(data).hexdigest()
hash_file = lambda path: sha(Path(path).read_bytes())

def source_inputs():
    files = [path for path in (root / 'src').rglob('*')
             if path.is_file()]
    files += [path for path in (root / 'assets').rglob('*') if path.is_file()]
    for name in ['App.tsx', 'index.tsx', 'app.json', 'package.json', 'package-lock.json',
                 'metro.config.js', 'babel.config.js', 'tsconfig.json', 'eas.json', '.easignore', 'metro/withNativeThree.js', 'metro/withReleaseComposition.js', 'metro/releaseDevStubs.js']:
        path = root / name
        if path.exists():
            files.append(path)
    return {str(path.relative_to(root)): hash_file(path) for path in sorted(files)}

baseline = source_inputs()
asset_paths = re.findall(r"require\('([^']+)'\)", (root / 'src/audio/sources.ts').read_text())
required_assets = {str((root / 'src/audio' / path).resolve().relative_to(root)): hash_file(root / 'src/audio' / path) for path in asset_paths}
assert len(required_assets) == 28
(evidence / 'source-before.json').write_text(json.dumps(baseline, indent=2)+'\n')
assert all(path in baseline for path in required)
start_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
source_status = subprocess.check_output(['git', 'status', '--porcelain', '--', 'src'], cwd=root, text=True).splitlines()
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()

def verify_inputs(label):
    current = source_inputs()
    (evidence / 'source-latest.json').write_text(json.dumps(current, indent=2)+'\n')
    changed = sorted(path for path in baseline.keys() | current.keys() if baseline.get(path) != current.get(path))
    if changed:
        (evidence / 'source-drift.json').write_text(json.dumps({'label': label, 'changed': changed}, indent=2)+'\n')
        raise RuntimeError('Source changed ' + label + ': ' + ', '.join(changed))

inspectors = ['scripts/inspect-bundle-sources.cjs', 'scripts/inspect-three-bundle.cjs',
              'scripts/check-release-export.cjs', 'scripts/inspect-metro-stage-entry.cjs']
tool_hashes = {path: hash_file(root / path) for path in inspectors}
tool_hashes[str(Path(__file__))] = hash_file(__file__)
tool_hashes[str(profile_script)] = hash_file(profile_script)
results = {}

def store_index():
    index_path.write_text(json.dumps(results, indent=2) + '\n')

for name, profile, mode, bytecode in [
    ('preview-hbc', 'preview', 'production', True),
    ('preview', 'preview', 'production', False),
    ('production', 'production', 'production', False),
    ('development', 'development', 'development', False),
]:
    verify_inputs('before ' + name)
    out = root / '.expo/goal014-1/exports/final' / name
    out.mkdir(parents=True, exist_ok=True)
    log_path = Path(str(evidence) + '/' + prefix + name + '-export.log')
    cache = root / '.expo/goal014-1/exports/cache-isolated-final'
    cache.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, NODE_ENV=mode, EXPO_PUBLIC_CHROMA_BUILD_PROFILE=profile, TMPDIR=str(cache))
    args = ['node', 'node_modules/expo/bin/cli', 'export', '--platform', 'ios', '--clear', '--max-workers', '2', '--output-dir', str(out)]
    if mode == 'development':
        args += ['--dev']
    if not bytecode:
        args += ['--no-bytecode', '--source-maps']
    print(json.dumps({'status': 'starting', 'export': name, 'directory': str(out), 'log': str(log_path)}), flush=True)
    result = {'directory': str(out), 'command': args,
              'environment': {'NODE_ENV': mode, 'EXPO_PUBLIC_CHROMA_BUILD_PROFILE': profile, 'TMPDIR': str(cache)},
              'log': str(log_path), 'bytecode': bytecode, 'checks': {}}
    results[name] = result
    store_index()
    with log_path.open('w') as log:
        completed = subprocess.run(args, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    result['exportExitCode'] = completed.returncode
    result['exportLogSha256'] = hash_file(log_path)
    store_index()
    if completed.returncode:
        raise RuntimeError(name + ' export failed; inspect ' + str(log_path))
    verify_inputs('after ' + name)
    metadata = json.loads((out / 'metadata.json').read_text())
    exported_assets = {hash_file(out / item['path']): item['path'] for item in metadata['fileMetadata']['ios']['assets']}
    assert all(digest in exported_assets for digest in required_assets.values()), 'Prepared audio asset missing from export'
    result['preparedAudioAssets'] = {file: {'sha256': digest, 'exportPath': exported_assets[digest]} for file, digest in required_assets.items()}
    result['all28AudioAssetsBundled'] = True
    bundles = [path for path in out.rglob('*') if path.suffix == ('.hbc' if bytecode else '.js') and path.parent.name == 'ios']
    assert len(bundles) == 1, bundles
    bundle = bundles[0]
    data = bundle.read_bytes()
    result.update({'bundle': str(bundle.relative_to(out)), 'sha256': sha(data), 'bytes': len(data),
                   'goal0141Present': b'goal-014-1-audio-ja-r1' in data,
                   'priorGoal014Present': b'goal-014-polish-r1' in data,
                   'sourceInputsStable': True})
    assert result['goal0141Present'] and not result['priorGoal014Present'], name + ' source marker mismatch'
    if bytecode:
        result['scope'] = 'Local preview-profile Hermes bytecode export; marker/content hash checked, no HBC execution or source-map factory inspection.'
    else:
        map_path = Path(str(bundle) + '.map')
        result['sourceMapSha256'] = hash_file(map_path)
        jobs = [('inspect-bundle-sources.cjs', [str(out), str(root)], 'sources'),
                ('inspect-three-bundle.cjs', [str(out), '--expect-single'], 'three')]
        jobs += [('inspect-metro-stage-entry.cjs', [str(out), str(root), '--expect-acyclic'], 'metro')] if mode == 'development' else [
            ('check-release-export.cjs', [str(out), 'ios'], 'release')]
        for tool, arguments, suffix in jobs:
            output = Path(str(evidence) + '/' + prefix + name + '-' + suffix + ('.log' if suffix == 'release' else '.json'))
            command = ['node', 'scripts/' + tool, *arguments]
            with output.open('w') as log:
                check = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT)
            entry = {'command': command, 'exitCode': check.returncode, 'output': str(output), 'outputSha256': hash_file(output)}
            result['checks'][suffix] = entry
            store_index()
            print(json.dumps({'export': name, 'inspector': tool, 'exitCode': check.returncode}), flush=True)
            if check.returncode:
                raise RuntimeError(name + ' ' + tool + ' failed; inspect ' + str(output))
            if suffix == 'sources':
                inspected = json.loads(output.read_text())
                mapped = {value['source']: value for value in inspected['sources']}
                assert inspected['ok'] and all(mapped[path]['matches'] for path in required)
                assert all(mapped[path]['mappedSha256'] == baseline[path] for path in required)
                entry.update({'firstPartyCount': inspected['firstPartyCount'], 'allMappedSourcesMatch': inspected['ok'],
                              'requiredSources': {path: mapped[path] for path in required},
                              'allMappedFirstPartyHashes': {path: value['mappedSha256'] for path, value in mapped.items()}})
            elif suffix == 'three':
                inspected = json.loads(output.read_text())
                assert inspected['sameClassIdentity']
                entry.update({'sameClassIdentity': True, 'threeSources': inspected['threeSources'], 'edges': inspected['edges']})
            elif suffix == 'release':
                entry['summary'] = output.read_text().strip()
            elif suffix == 'metro':
                inspected = json.loads(output.read_text())
                assert not inspected['missingRoots'] and not inspected['firstPartyCycles']
                assert all(value['passed'] for value in inspected['observations'])
                assert all(value['buildIdentity']['code'] == 'goal-014-1-audio-ja-r1' for value in inspected['observations'])
                entry.update({'scope': inspected['scope'], 'preludeUnmodified': inspected['preludeUnmodified'],
                              'loaderUnmodified': inspected['loaderUnmodified'], 'firstPartyFactoriesUnmodified': inspected['firstPartyFactoriesUnmodified'],
                              'factorySubstitutions': inspected['factorySubstitutions'], 'registeredModules': inspected['registeredModules'],
                              'missingRoots': inspected['missingRoots'], 'firstPartyCycles': inspected['firstPartyCycles'],
                              'observations': inspected['observations'], 'nativeDeviceStartup': inspected['nativeDeviceStartup']})
            verify_inputs('after ' + name + ' ' + suffix)
            store_index()
    store_index()
    print(json.dumps({'status': 'passed', 'export': name, 'sha256': result['sha256']}), flush=True)

profile_log = Path(str(evidence) + '/' + prefix + 'profile-proof.log')
with profile_log.open('w') as log:
    evaluated = subprocess.run(['node', str(profile_script)], cwd=root, stdout=log, stderr=subprocess.STDOUT)
if evaluated.returncode:
    raise RuntimeError('Compiled profile proof failed; inspect ' + str(profile_log))
profile_proof = json.loads(profile_output.read_text())
assert profile_proof['preview']['internalDiagnosticsEnabled'] is True
assert profile_proof['production']['internalDiagnosticsEnabled'] is False
verify_inputs('after all exports and actual factory evaluation')
for path, expected in tool_hashes.items():
    assert hash_file(Path(path) if Path(path).is_absolute() else root / path) == expected, path
end_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
commit_mismatches = []
for path, expected in baseline.items():
    committed = subprocess.run(['git', 'show', end_head + ':' + path], cwd=root, capture_output=True)
    if committed.returncode or sha(committed.stdout) != expected:
        commit_mismatches.append(path)

report = {
    'schemaVersion': 1, 'label': 'GOAL_014_1_LOCAL_BUNDLES', 'startedAt': started_at,
    'finishedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'sourceCommit': end_head if not commit_mismatches else None,
    'startHead': start_head, 'endHead': end_head,
    'sourceInputsMatchEndCommit': not commit_mismatches, 'endCommitMismatchedInputs': commit_mismatches,
    'sourceCommitScope': 'Exact guarded input hashes determine correspondence. End HEAD is recorded as sourceCommit only when every input matches its committed bytes; committing identical source during export is allowed.',
    'sourceWorktreeStatus': source_status, 'sourceHashes': baseline, 'sourceInputsStableAcrossAllExports': True,
    'toolHashes': tool_hashes, 'exports': results, 'profileFactoryEvaluation': profile_proof,
    'profileFactoryCommand': ['node', str(profile_script)],
    'profileFactoryOutputSha256': hash_file(profile_output), 'profileFactoryExitCode': evaluated.returncode,
    'requiredCurrentSourcePaths': required,
    'validation': {'fourLocalExports': len(results) == 4,
                   'all28AudioAssetsBundled': all(value['all28AudioAssetsBundled'] for value in results.values()),
                   'goal0141PresentPriorGoal014AbsentAllBundles': all(value['goal0141Present'] and not value['priorGoal014Present'] for value in results.values()),
                   'allInspectorsPassed': all(check['exitCode'] == 0 for value in results.values() for check in value['checks'].values()),
                   'compiledPreviewDiagnosticsEnabled': profile_proof['preview']['internalDiagnosticsEnabled'],
                   'compiledProductionDiagnosticsDisabled': not profile_proof['production']['internalDiagnosticsEnabled']},
    'identityLimits': [
        'Exports are local Metro/Hermes artifacts, not EAS cloud builds or installed native binaries.',
        'Preview/production identities execute actual mapped minified buildIdentity and required Babel/app.json factories only.',
        'Unavailable native Expo Constants is explicitly substituted with an empty object; nativeBuild remains unknown.',
        'Development inspection executes the actual Metro prelude, loader, and domain/controller/Three factories; only the external native Constants facade is seeded.',
        'HBC marker/source-guard checks do not claim Hermes runtime or iPhone execution.',
        'No EAS build ID, installed build number, native GL success, device identity or presentation acceptance is inferred from these artifacts.'
    ],
    'nativeDeviceAcceptance': 'PENDING', 'RELEASE_READY': False,
}
assert all(report['validation'].values())
report['sourceGuardScope'] = 'All filesystem files under src and assets (including tests, testFixtures and untracked files), App/index and listed package/Expo/EAS/Metro configuration; immutable input hashes rather than HEAD equality. No source/config edits by exporter.'
report['guardedInputCount'] = len(baseline)
report['audioAssets'] = required_assets
report['archiveLogs'] = []
for artifact in sorted(evidence.iterdir()):
    if artifact.suffix not in ['.log','.json'] or artifact.name in ['source-latest.json']: continue
    dest=report_path.parent/(artifact.name+'.gz')
    dest.write_bytes(gzip.compress(artifact.read_bytes(),mtime=0))
    report['archiveLogs'].append({'path':str(dest.relative_to(root)), 'sha256':hash_file(dest), 'rawSha256':hash_file(artifact), 'rawPath':str(artifact.relative_to(root))})
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'status': 'all-passed', 'report': str(report_path), 'sha256': hash_file(report_path), 'validation': report['validation']}), flush=True)
