from pathlib import Path
import datetime
import hashlib
import json
import subprocess

root = Path.cwd()
def git(*args):
    return subprocess.check_output(['git', *args])
def digest(data):
    return hashlib.sha256(data).hexdigest()

check_path = root / 'docs/qa-goal014-1/final-checks/check-attempt-01.json'
check = json.loads(check_path.read_text())
paths = sorted(set(git('ls-files', '--cached', '--others', '--exclude-standard').decode().splitlines()))
paths = [p for p in paths if not p.startswith('docs/')]
current = {p: digest((root / p).read_bytes()) for p in paths}
missing = sorted(set(check['sourceHashes']) - set(current))
changed = [p for p, value in check['sourceHashes'].items() if current.get(p) != value]
added = sorted(set(current) - set(check['sourceHashes']))
assert not missing and not changed, (missing, changed)
assert added == ['scripts/qa-player-resume-app.cjs', 'scripts/qa-player-ui-comparison.cjs'], added
index_mismatch = [p for p, value in current.items() if digest(git('show', ':' + p)) != value]
assert not index_mismatch, index_mismatch
product_commit = '6186a5e5c22718ffd9af57b8236e8ffbf89867cb'
product_paths = [p for p in paths if not p.startswith(('scripts/', 'test-support/'))]
product_mismatch = [p for p in product_paths if digest(git('show', product_commit + ':' + p)) != current[p]]
assert not product_mismatch, product_mismatch
protected = ['package.json', 'package-lock.json', 'app.json', 'eas.json', 'metro.config.js', 'metro/withNativeThree.js']
protected_result = {p: digest(git('show', '393e58e:' + p)) == current[p] for p in protected}
asset_paths = git('ls-tree', '-r', '--name-only', '393e58e', '--', 'assets').decode().splitlines()
asset_changed = [p for p in asset_paths if digest(git('show', '393e58e:' + p)) != current[p]]
assert all(protected_result.values()) and not asset_changed
report = {
    'schemaVersion': 1,
    'checkedAtUTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'worktree': str(root),
    'branch': git('branch', '--show-current').decode().strip(),
    'implementationCommits': ['e2af6eb', product_commit],
    'scope': 'Working bytes and staged Git objects checked before the QA/documentation commit. Product files additionally match the existing implementation commit. Final commit identity is reported in Git and the final handoff; no future hash is fabricated.',
    'fullCheck': {'record': str(check_path.relative_to(root)), 'recordSha256': digest(check_path.read_bytes()), 'inputCount': len(check['sourceHashes']), 'missing': missing, 'changed': changed, 'passedSuites': 134, 'passedTests': 1327},
    'additionalQAOnlyFiles': [{'path': p, 'sha256': current[p]} for p in added],
    'additionalQAVerification': ['docs/qa-goal014-1/player-resume-app/README.md', 'docs/qa-goal014-1/player-ui-comparison/verification.json'],
    'sourceFilesChecked': len(current),
    'stagedSourceObjectsMatchWorkingTree': not index_mismatch,
    'committedProductFilesChecked': len(product_paths),
    'committedProductMismatches': product_mismatch,
    'protectedFilesMatchBaseline': protected_result,
    'baselineAssetsChecked': len(asset_paths),
    'changedBaselineAssets': asset_changed,
    'sourceSetSha256': digest(json.dumps(current, sort_keys=True, separators=(',', ':')).encode()),
    'sourceHashes': current,
    'DEVICE_ACCEPTANCE': 'PENDING',
    'RELEASE_READY': False,
}
out = root / 'docs/qa-goal014-1/source-correspondence.json'
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'sourceHashes'}, ensure_ascii=False, indent=2))
