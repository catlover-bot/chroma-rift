import concurrent.futures, datetime, hashlib, json, subprocess, time
from pathlib import Path
out=Path('.expo/goal014-1/final-checks')
commands={'npm-ls':['npm','ls','--depth=0','--json'],'expo-install-check':['npx','expo','install','--check'],'doctor':['npm','run','doctor'],'audit':['npm','audit','--json']}
def run(item):
 name,command=item; begin=time.monotonic(); log=out/(name+'.log')
 with log.open('w') as f: result=subprocess.run(command,stdout=f,stderr=subprocess.STDOUT)
 return name,{'command':command,'exitCode':result.returncode,'elapsedSeconds':round(time.monotonic()-begin,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=dict(pool.map(run,commands.items()))
report={'checkedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':results}
(out/'environment.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2),flush=True)
