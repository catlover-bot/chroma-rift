import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path.cwd();out=root/'.expo/goal014-1/final-checks';name='check-attempt-01'
files=sorted(set(subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard'],text=True).splitlines()))
files=[p for p in files if not p.startswith('docs/') and (root/p).is_file()]
hashfile=lambda p:hashlib.sha256((root/p).read_bytes()).hexdigest()
before={p:hashfile(p) for p in files};(out/(name+'-sources.json')).write_text(json.dumps(before,indent=2)+'\n')
env=os.environ.copy();env['CHROMA_QA_AUDIO_TRACE']=str(out/'app-audio.json')
log=out/(name+'.log');begin=time.monotonic()
with log.open('w') as f: result=subprocess.run(['npm','run','check'],stdout=f,stderr=subprocess.STDOUT,env=env)
changed=[p for p,h in before.items() if not (root/p).is_file() or hashfile(p)!=h]
report={'command':['npm','run','check'],'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'finishedAtUTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exitCode':result.returncode,'elapsedSeconds':round(time.monotonic()-begin,3),'sourceFilesChecked':len(before),'changedSources':changed,'log':str(log.relative_to(root)),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest(),'sourceHashes':before}
(out/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='sourceHashes'},indent=2),flush=True)
print('\n'.join(log.read_text().splitlines()[-65:]),flush=True)
raise SystemExit(result.returncode or bool(changed))
